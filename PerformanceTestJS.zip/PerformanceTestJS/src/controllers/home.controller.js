import ReservationCard from "@components/ReservationCard";
import {
  getReservations,
  createReservation,
  updateReservation,
} from "@services/reservation.service";
import { getSession } from "@/utils";

export const homeController = async () => {
  console.log("HOME CONTROLLER EJECUTADO");
  const container = document.querySelector("#reservationsContainer");
  const user = getSession();

  // Variable de estado local para saber qué reserva se está editando
  // Si es null, significa que el modal está en modo "Crear Nueva"
  let editingReservationId = null;

  // Referencias a los elementos del DOM del Modal y Formulario
  const newReservationBtn = document.querySelector("#newReservationBtn");
  const modal = document.querySelector("#reservationModal");
  const modalTitle = modal?.querySelector("h2"); // Título dinámico del modal
  const closeModal = document.querySelector("#closeReservationModal");
  const form = document.querySelector("#reservationForm");

  // Función para renderizar la lista de reservas
  const renderReservations = (reservationsList) => {
    const filtered =
      user.role === "admin"
        ? reservationsList
        : reservationsList.filter(
            (res) => res.userId?.toString() === user.id?.toString(),
          );

    container.innerHTML = filtered?.length
      ? filtered.map((reservation) => ReservationCard(reservation)).join("")
      : `
        <div class="w-full text-center py-8 col-span-2">
          <p class="text-slate-500">No hay reservas disponibles</p>
        </div>
      `;
  };

  // Carga inicial de datos
  const reservations = await getReservations();
  renderReservations(reservations);

  // --- ESCUCHAR CLICS EN LOS BOTONES DE LAS CARDS (DELEGACIÓN DE EVENTOS) ---
  container?.addEventListener("click", async (e) => {
    const button = e.target.closest("button[data-action]");
    if (!button) return;

    const action = button.getAttribute("data-action");
    const reservationId = button.getAttribute("data-id");

    try {
      if (action === "approve") {
        await updateReservation(reservationId, { status: "approved" });
      } else if (action === "reject") {
        await updateReservation(reservationId, { status: "rejected" });
      } else if (action === "cancel") {
        await updateReservation(reservationId, { status: "canceled" });
      } else if (action === "delete") {
        if (confirm("¿Estás seguro de que deseas eliminar esta reserva?")) {
          // Si no tienes deleteReservation importado arriba, usamos la API directa o tu servicio
          // Asumiendo que tu servicio tiene deleteReservation listo en reservation.service.js:
          const { deleteReservation } =
            await import("@services/reservation.service");
          await deleteReservation(reservationId);
        } else {
          return;
        }
      }
      // --- LÓGICA DE EDICIÓN ---
      else if (action === "edit") {
        // 1. Encontrar los datos actuales de la reserva localmente para no re-consultar la API
        const allRes = await getReservations();
        const currentRes = allRes.find(
          (r) => r.id.toString() === reservationId.toString(),
        );

        if (!currentRes) return;

        // 2. Cambiar el estado a modo edición guardando el ID
        editingReservationId = reservationId;

        // 3. Rellenar los campos del formulario con los datos viejos
        form.workspace.value = currentRes.workspace;
        form.date.value = currentRes.date;
        form.startHour.value = currentRes.startHour;
        form.endHour.value = currentRes.endHour;
        form.reason.value = currentRes.reason;

        // 4. Cambiar el aspecto visual del modal para que el usuario sepa que está editando
        if (modalTitle) modalTitle.innerText = "Editar Reserva";
        const submitBtn = form.querySelector("button[type='submit']");
        if (submitBtn) submitBtn.innerText = "Actualizar Cambios";

        // 5. Abrir el modal
        modal?.classList.remove("hidden");
        return; // Salimos para evitar que refresque la lista antes de guardar
      }

      // Refrescar la pantalla después de Aprobar, Rechazar o Cancelar
      const updatedData = await getReservations();
      renderReservations(updatedData);
    } catch (error) {
      console.error("Error en la acción de la tarjeta:", error);
      alert("Hubo un error al procesar la solicitud.");
    }
  });

  // --- LÓGICA DE APERTURA Y CIERRE DEL MODAL ---
  newReservationBtn?.addEventListener("click", () => {
    editingReservationId = null; // Modo "Crear Nueva"
    form.reset(); // Limpiar inputs
    if (modalTitle) modalTitle.innerText = "Nueva Reserva";
    const submitBtn = form.querySelector("button[type='submit']");
    if (submitBtn) submitBtn.innerText = "Guardar Reserva";
    modal?.classList.remove("hidden");
  });

  closeModal?.addEventListener("click", () => {
    modal?.classList.add("hidden");
    form.reset();
  });

  // --- LÓGICA DEL SUBMIT (GUARDA O ACTUALIZA SEGÚN CORRESPONDA) ---
  form?.addEventListener("submit", async (e) => {
    e.preventDefault();

    const inputWorkspace = form.workspace.value.trim();
    const inputDate = form.date.value;
    const inputStart = form.startHour.value;
    const inputEnd = form.endHour.value;
    const inputReason = form.reason.value.trim();

    if (inputStart >= inputEnd) {
      alert("La hora de inicio debe ser menor que la hora de fin.");
      return;
    }

    try {
      const allReservations = await getReservations();

      // Validación de Choque de Horarios
      const conflictingReservations = allReservations.filter((res) => {
        // Excluir la reserva que estamos editando actualmente de la validación de choque de horarios
        if (
          editingReservationId &&
          res.id.toString() === editingReservationId.toString()
        ) {
          return false;
        }
        const sameSpace =
          res.workspace.toLowerCase() === inputWorkspace.toLowerCase();
        const sameDate = res.date === inputDate;
        const isActive = res.status === "pending" || res.status === "approved";
        return sameSpace && sameDate && isActive;
      });

      const hasOverlap = conflictingReservations.some((res) => {
        return inputStart < res.endHour && inputEnd > res.startHour;
      });

      if (hasOverlap) {
        alert(
          `⚠️ Conflicto de horario: El espacio "${inputWorkspace}" ya se encuentra ocupado en ese rango.`,
        );
        return;
      }

      // Decidir si enviamos un POST (Nueva) o un PATCH (Editar)
      if (editingReservationId) {
        // MODO EDICIÓN: Actualizar registro existente
        await updateReservation(editingReservationId, {
          workspace: inputWorkspace,
          date: inputDate,
          startHour: inputStart,
          endHour: inputEnd,
          reason: inputReason,
          status: "pending", // Al editar, vuelve a quedar pendiente según reglas estándar de auditoría
        });
        alert("¡Reserva actualizada con éxito!");
      } else {
        // MODO CREACIÓN: Guardar registro nuevo
        await createReservation({
          userId: user.id,
          workspace: inputWorkspace,
          date: inputDate,
          startHour: inputStart,
          endHour: inputEnd,
          reason: inputReason,
          status: "pending",
        });
        alert("¡Reserva solicitada con éxito!");
      }

      // Resetear estado del formulario y cerrar
      editingReservationId = null;
      const updatedReservations = await getReservations();
      renderReservations(updatedReservations);

      form.reset();
      modal?.classList.add("hidden");
    } catch (error) {
      console.error(error);
      alert("Error al procesar el formulario.");
    }
  });
};
