import { getSession, isAdmin } from "@/utils";

export default function ReservationCard(reservation) {
  const { id, workspace, date, startHour, endHour, reason, status } =
    reservation;
  const user = getSession();
  const userIsAdmin = isAdmin();

  // Construcción dinámica de botones sin alterar tu diseño base
  let actionButtons = "";

  if (userIsAdmin) {
    // Si es Administrador: Aprobar y Rechazar (si está pendiente), y Eliminar siempre
    actionButtons = `
      <div class="mt-3 flex gap-2 border-t pt-2">
        ${
          status === "pending"
            ? `
          <button data-action="approve" data-id="${id}" class="bg-green-600 text-white text-xs px-2 py-1 rounded">Aprobar</button>
          <button data-action="reject" data-id="${id}" class="bg-orange-500 text-white text-xs px-2 py-1 rounded">Rechazar</button>
        `
            : ""
        }
        <button data-action="delete" data-id="${id}" class="bg-red-600 text-white text-xs px-2 py-1 rounded ml-auto">Eliminar</button>
      </div>
    `;
  } else {
    // Si es Usuario normal: Editar (solo si está pendiente) y Cancelar (si está pendiente o aprobada)
    if (status === "pending") {
      actionButtons = `
        <div class="mt-3 flex gap-2 border-t pt-2">
          <button data-action="edit" data-id="${id}" class="bg-blue-600 text-white text-xs px-2 py-1 rounded">Editar</button>
          <button data-action="cancel" data-id="${id}" class="bg-gray-500 text-white text-xs px-2 py-1 rounded">Cancelar</button>
        </div>
      `;
    } else if (status === "approved") {
      actionButtons = `
        <div class="mt-3 flex gap-2 border-t pt-2">
          <button data-action="cancel" data-id="${id}" class="bg-gray-500 text-white text-xs px-2 py-1 rounded w-full">Cancelar Reserva</button>
        </div>
      `;
    }
  }

  return `
    <article
      class="bg-white p-4 rounded-lg shadow border"
    >
      <h3 class="font-bold text-lg">
        ${workspace}
      </h3>

      <div class="mt-2 text-sm">

        <p>
          Fecha:
          ${date}
        </p>

        <p>
          Horario:
          ${startHour}
          -
          ${endHour}
        </p>

        <p>
          Motivo:
          ${reason}
        </p>

        <p>
          Estado:
          <span class="font-semibold">
            ${status}
          </span>
        </p>

      </div>

      ${actionButtons}
    </article>
  `;
}
