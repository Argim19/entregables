import { removeSession } from "@/utils";
import { navigateTo } from "@/router/router";

export default function Sidebar() {
  setTimeout(() => {
    // Manejo del Logout
    document.querySelector("#logoutBtn")?.addEventListener("click", () => {
      removeSession();
      navigateTo("/");
    });

    // Interceptar clics de navegación SPA para evitar recarga de página
    document.querySelectorAll("[data-link]").forEach((link) => {
      link.addEventListener("click", (e) => {
        e.preventDefault();
        const targetPath = link.getAttribute("href");
        navigateTo(targetPath);
      });
    });
  });

  return `
    <aside class="w-64 bg-slate-900 text-white h-screen p-5">
      <h2 class="text-2xl font-bold mb-8">Riwi Workspaces</h2>

      <nav class="flex flex-col gap-4">
        <a href="/home" class="px-3 py-2 bg-slate-800 rounded-xl hover:bg-slate-700 transition" data-link>
          📅 Ver Reservas
        </a>

        <button
          id="logoutBtn"
          class="text-left cursor-pointer text-red-400 hover:text-white hover:bg-red-500 px-3 py-2 rounded-xl transition mt-auto"
        >
          🚪 Cerrar sesión
        </button>
      </nav>
    </aside>
  `;
}
