export default function reservationFormView() {
  return `
    <div class="bg-white p-5 rounded-lg shadow mb-6">
      <h2 class="text-xl font-bold mb-4">
        Nueva Reserva
      </h2>

      <form id="reservationForm">

        <input
          type="text"
          name="workspace"
          placeholder="Espacio de trabajo"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <input
          type="date"
          name="date"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <input
          type="time"
          name="startHour"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <input
          type="time"
          name="endHour"
          class="border w-full p-2 rounded mb-3"
          required
        >

        <textarea
          name="reason"
          placeholder="Motivo"
          class="border w-full p-2 rounded mb-3"
          required
        ></textarea>

        <button
          class="bg-green-600 text-white px-4 py-2 rounded"
        >
          Guardar Reserva
        </button>

      </form>
    </div>
  `;
}
